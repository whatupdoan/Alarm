import time
""" local time """
hour = int(input("Merhaba, Alarm Saatinizi Kaça Kurmak İstersiniz?\n Saat Giriniz :"
))
minute = int(input("Dakika : "))

while True:
    saat = time.localtime(time.time())

    if hour == saat.tm_hour and minute == saat.tm_min:
        print ("Alarm Çaldı!\nSaat ", saat.tm_hour, ":", saat.tm_min)
        break
        pass

print("Program Döngüden Çıktı!")

'''
 Program Kolay ve Geliştirilebilir Açık Kaynaktır. Öncelikle Programın Çalışma Mantığı: 
        Başlattığımızda Saat ve Dakika Gireceğiz. Girdiğimiz Saat ve Dakika Bilgisayar Saatimiz İle Aynı Olduğunda Program Bize Mesaj Gönderecek.
 
     Muhammet Tezcan - is now learning Python
'''